/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AppointmentApp.Model;

/**
 *
 * @author Muhammad Aarij
 */
public class Branch extends StringHandler {
    //private String branch;

    public String getBranch() {
        return super.randomString;
    }

    public void setBranch(String branch) {
        this.randomString = branch;
    }

}
