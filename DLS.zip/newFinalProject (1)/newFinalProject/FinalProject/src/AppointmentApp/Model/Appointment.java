/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AppointmentApp.Model;

/**
 *
 * @author Muhammad Aarij
 */
//    public class Appointment {
//    private String user;
//    private String userCNIC;
//    private String branch;
//    private String licensetype;
//    private String timeslot;
//
//    private SeatSlot slot;
//
//    public SeatSlot getSlot() {
//        return slot;
//    }
//
//    public void setSlot(SeatSlot slot) {
//        this.slot = slot;
//    }
//
//    public String getTimeslot() {
//     
//        return this.timeslot;
//    }
//
//    public void setTimeslot(String timeslot) {
//        this.timeslot = timeslot;
//    }
//    
//
//    public String getLicensetype() {
//        return this.licensetype;
//    }
//
//    public void setLicensetype(String licensetype) {
//        this.licensetype = licensetype;
//    }
//
//    public String getB() {
//        return this.branch;
//    }
//
//    public void setBranch(String branch) {
//       
//        this.branch = branch;
//    }
//
//    public String getUserName() {
//        return this.user;
//    }
//
//    public void setUserName(String Name) {
//        this.user=Name;
//    }
//    
//    public String getUserCNIC() {
//       
//        return this.userCNIC;
//    }
//
//    public void setUserCNIC(String userCNIC) {
//        this.userCNIC = userCNIC;
//    }
//    
//}
public class Appointment {

    private User user;
    private Branch branch;
    private LicenseType licensetype;
    private TimeSlot timeslot;

    private SeatSlot slot;

    public void setUSER(User user) {
        this.user = user;
    }

    public User getUSER() {
        return user;
    }

    public void setBRANCH(Branch branch) {
        this.branch = branch;
    }

    public Branch getBRANCH() {
        return branch;
    }

    public void setLICENSETYPE(LicenseType licenseType) {
        this.licensetype = licenseType;
    }

    public LicenseType getLICENSETYPE() {
        return licensetype;
    }

    public SeatSlot getSlot() {
        return slot;
    }

    public void setSlot(SeatSlot slot) {
        this.slot = slot;
    }

    public void setTIMESLOT(TimeSlot timeSlot) {
        this.timeslot = timeSlot;
    }

    public TimeSlot getTIMESLOT() {
        return timeslot;
    }

}
