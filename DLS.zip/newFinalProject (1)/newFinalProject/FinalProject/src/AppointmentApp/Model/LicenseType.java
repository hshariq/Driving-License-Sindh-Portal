/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AppointmentApp.Model;

/**
 *
 * @author Muhammad Aarij
 */
public class LicenseType extends StringHandler {
    //private String licensetype;

    public String getLicensetype() {
        return super.randomString;
    }

    public void setLicensetype(String licensetype) {
        super.randomString = licensetype;
    }
}
